import ProjectForm from '@/components/ProjectForm';

const ProjectFormPage = () => {
  return (
    <div className="min-h-screen pt-16">
      <ProjectForm />
    </div>
  );
};

export default ProjectFormPage;