import Students from '@/components/Students';

const StudentsPage = () => {
  return (
    <div className="min-h-screen pt-16">
      <Students />
    </div>
  );
};

export default StudentsPage;