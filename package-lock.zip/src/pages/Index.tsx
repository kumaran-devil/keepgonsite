// This file is now replaced by the new routing structure
// The content has been moved to separate pages: Home, ServicesPage, StudentsPage, ContactPage

export { default } from './Home';
