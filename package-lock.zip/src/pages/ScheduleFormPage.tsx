import ScheduleProjectForm from '@/components/ScheduleForm';

const ScheduleFormPage = () => {
  return (
    <div className="min-h-screen pt-16">
      <ScheduleProjectForm />
    </div>
  );
};

export default ScheduleProjectForm;