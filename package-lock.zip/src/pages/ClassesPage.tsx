import Classes from '@/components/Classes';
import Services from '@/components/Classes';

const ServicesPage = () => {
  return (
    <div className="min-h-screen pt-16">
      <Classes />
    </div>
  );
};

export default ServicesPage;